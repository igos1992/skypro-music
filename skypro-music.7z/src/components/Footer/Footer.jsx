function Footer() {
  return (
    <footer className="footer" />
  );
}

export default Footer;