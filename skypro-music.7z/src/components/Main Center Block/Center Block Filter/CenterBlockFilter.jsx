import {
  useEffect,
  useState
} from 'react';
import {
  useDispatch, useSelector
} from 'react-redux';
import { useGetAllMusicQuery } from '../../../redux/music/serviceQuery';
import * as S from './CenterBlockFilter.style';
import {
  // selectDeleteSortTrackFilter,
  selectFilterAuthors,
  selectFilterGenres,
  selectSortTrackFilter,
  setDeleteFilterAuthors,
  setDeleteFilterGenres,
  setDeleteSortTrackFilter,
  // setDeterminingTheActiveFilter,
  setFilterAuthors,
  // selectFilterGenres, 
  // selectFilterSort, 
  setFilterGenres,
  setSortTrackFilter,
  // setSortTrackFilter
} from '../../../redux/music/musicSlice';



function CenterBlockFilter() {

  const { data } = useGetAllMusicQuery()

  console.log(data);

  const dispatch = useDispatch()
  const [activeFilter, setActiveFilter] = useState();
  const [genreArray, setGenreArray] = useState([])
  const [authorArray, setAuthorArray] = useState([])
  const [sortRelease, setSortRelease] = useState([])


  useEffect(() => {
    if (data?.length > 0) {
      let newArr = []
      let arr = data.map(elem => elem.genre)
      for (let i = 0; i < arr.length; i++) {
        if (newArr.includes(arr[i])) continue
        newArr.push(arr[i])
      }
      setGenreArray(newArr)
      setAuthorArray(data.map(elem => elem.author))
      setSortRelease(data.map(elem => elem.release_date))
    }

  }, [data, activeFilter])


  const authorTrackFilter = useSelector(selectFilterAuthors)
  const genreTrackFilter = useSelector(selectFilterGenres)
  const releaseTrackFilter = useSelector(selectSortTrackFilter)

  console.log(genreArray);
  console.log(authorArray);
  console.log(sortRelease);


  const handleAuthorTrackFilter = (authorTrack) => {
    if (authorTrackFilter.includes(authorTrack)) {
      dispatch(setDeleteFilterAuthors(authorTrack))
    } else {
      dispatch(setFilterAuthors(authorTrack))
    }
  }

  const handleGenreTrackFilter = (genreTrack) => {
    if (genreTrackFilter.includes(genreTrack)) {
      dispatch(setDeleteFilterGenres(genreTrack))
    } else {
      dispatch(setFilterGenres(genreTrack))
    }
  }

  const handleSortTrackFilter = (releaseTrack) => {
    if (releaseTrackFilter.includes(releaseTrack)) {
      dispatch(setDeleteSortTrackFilter(releaseTrack))
    } else {
      dispatch(setSortTrackFilter(releaseTrack))
    }
  }

  const toggleVisibleFilter = (filter) => {
    setActiveFilter(activeFilter === filter ? null : filter)
  };




  return (

    <S.CenterBlockFilter>
      <S.FilterNameGenre>
        <S.FilterTitle >Искать по:</S.FilterTitle>
        <S.FilterWrap>
          <S.FilterButton
            onClick={() => toggleVisibleFilter("author")}
          >
            исполнителю
          </S.FilterButton>
          {activeFilter === "author" &&
            <>
              <S.FilterLength>
                {authorArray.length}
              </S.FilterLength>
              <S.FilterMenu>
                <S.FilterList>
                  {authorArray.map((author, index) => (
                    <li key={`item-${index}`}>
                      <S.TextDecoration href='#'
                        onClick={() => handleAuthorTrackFilter(author)}
                      >{author}</S.TextDecoration>
                    </li>
                  ))}
                </S.FilterList>
              </S.FilterMenu>
            </>}
        </S.FilterWrap>

        <S.FilterWrap>
          <S.FilterButton onClick={() => toggleVisibleFilter("genre")}>
            жанру
          </S.FilterButton>
          {activeFilter === "genre" &&
            <>
              <S.FilterLength>
                {genreArray.length}
              </S.FilterLength>
              <S.FilterMenu>
                <S.FilterList>
                  {genreArray.map((genre) => (
                    <li key={genre}>
                      <S.TextDecoration href='#'
                        onClick={() => handleGenreTrackFilter(genre)
                        }

                      >{genre}</S.TextDecoration>
                    </li>
                  ))}
                </S.FilterList>
              </S.FilterMenu>
            </>}
        </S.FilterWrap>
      </S.FilterNameGenre>

      <S.FilterByDate>
        <S.FilterTitle>Сортировка:</S.FilterTitle>
        <S.FilterWrap>
          <S.FilterButton onClick={() => toggleVisibleFilter("sorting")}>
            По умолчанию
          </S.FilterButton>
          {activeFilter === "sorting" &&
            <>
              <S.FilterLength >
                {sortRelease.length}
              </S.FilterLength>
              <S.FilterMenuYear>
                <S.FilterList>
                  {sortRelease.map((sorting, i) => (
                    <li key={`item-${i}`}>
                      <S.TextDecoration href='#'
                        onClick={() => handleSortTrackFilter(sorting)}>
                        {sorting}
                      </S.TextDecoration>
                    </li>
                  ))}
                </S.FilterList>
              </S.FilterMenuYear>
            </>}
        </S.FilterWrap>
      </S.FilterByDate>

    </S.CenterBlockFilter >
  )
}

export default CenterBlockFilter;