export const ArrayCollectionPages = [
{
  namePage: 'category 1',
  img: '../img/playlist01.png',
  id: 1
},
{
  namePage: 'category 2',
  img: '../img/playlist02.png',
  id: 2
},
{
  namePage: 'category 3',
  img: '../img/playlist03.png',
  id: 3
}
];