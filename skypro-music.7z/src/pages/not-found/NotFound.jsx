import * as S from './NotFound.style'

export const NotFound = () => {
  return (
    <S.NotFound>
      <h1>Page was not found</h1>
    </S.NotFound>
  );
}